# Extend clingo with hitting set based optimization

```bash
python clingo-hit.py example.lp
```
